//
//  AppDelegate.h
//  iOS Demo
//
//  Created by Ariel Elkin on 03/03/2014.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
